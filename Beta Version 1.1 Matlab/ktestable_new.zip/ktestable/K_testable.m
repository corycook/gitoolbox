kset = KBuilder('sample.txt', 3);
dfa = K2dfa(kset);


