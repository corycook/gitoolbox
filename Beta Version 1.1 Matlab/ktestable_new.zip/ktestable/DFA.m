% Hasan Ibne Akram
% Munich University of Technology
% Email: hasan.akram@sec.in.tum.de
% Copyright © 2009

%-------------------------------------------------


classdef DFA

    % This class deinfes the DFA structure
    
    properties
    
        FiniteSetOfStates   % FiniteSetOfStates is the set of finite states donated as Q
        Alphabets   % the set of alphabets
        TransitionMatrix  % the state transition matrix. 'X' is denoted as no transition
        InitialState   % the set of initial states
        FinalAcceptStates   % the set of final accepting states
        FinalRejectStates  % the rejecting states
        
        % Optional propoerties, needed in case of implmenting RPNI version
        % of Colin de la Higuera, http://labh-curien.univ-st-etienne.fr/~cdlh/book/
        
        RED % set of all the red states
        BLUE % set of all the blue states
        
    end
    
    methods
%        % contructor
%        function obj = DFA(q, a, tm, i, fa, fr)
%             obj.FiniteSetOfStates = q;
%             obj.Alphabets = a;
%             obj.TransitionMatrix = tm;
%             obj.InitialState = i;
%             obj.FinalAcceptStates = fa;
%             obj.FinalRejectStates = fr;           
%        end
        
       % This constructor is needed in case of implmenting RPNI version
       % of Colin de la Higuera, http://labh-curien.univ-st-etienne.fr/~cdlh/book/
       
       function obj = DFA(q, a, tm, i, fa, fr, red, blue)
            obj.FiniteSetOfStates = q;
            obj.Alphabets = a;
            obj.TransitionMatrix = tm;
            obj.InitialState = i;
            obj.FinalAcceptStates = fa;
            obj.FinalRejectStates = fr;  
            obj.RED = red;
            obj.BLUE = blue;
       end
        
    end
end

